import mysql.connector
con = mysql.connector.connect(host='localhost',database='LIVRARIA',user='root',password='')
cursor=con.cursor()

from Conector import cursor
from Livros import Livros



class LivrosDAO:
#    con=None
#   cursor=None
    def __init__(self):
        self.con=None
        self.cursor=None
    def conectar(self):
        self.con=mysql.connector.connect(host='localhost', database='Livraria',user='root',password='')
        if not self.con.is_connected():
            return False
        self.cursor=self.con.cursor()
        return True

    def desconectar(self):
        if self.con.is_connected():
            self.con.close()

    def cadastrar(self, livros):


            sql = 'insert into Livros values (%s,%s,%s,%s,%s,%s)'
            valores = (livros.getCodigo(), livros.getNome(),
                       livros.getAutor(), livros.getEditora(),
                       livros.getAno(), livros.getPreco())
            if not self.conectar():
                return False
            self.cursor.execute(sql, valores)
            self.con.commit()
            if self.cursor.rowcount > 0:
                return True
            return False


    def consultar(self, livros):
        # selecionando todos os registros da tabela

        sql = ("SELECT codigo,nome,autor,editora,ano, preco FROM livros")
        cursor.execute(sql)
        # acessando cada registro
        for (codigo,nome,autor,editora,ano, preco) in cursor:
            print('Codigo: ', codigo, '\nNome: ', nome, '\nAutor:', autor,'\nEditora: ', editora, '\nAno: ', ano, '\nPreco:', preco)

        # selecionando um registro específico da tabela
        cursor.execute("Select * from Livros where codigo=''")
        resultado = cursor.fetchall()
        for linha in resultado:  # recupera o registro num vetor
            print('\nCodigo: ', linha[0], '\nNome: ', linha[1], '\nAutor:', linha[2],'\nEditora: ', linha[3], '\nAno: ', linha[4], '\nPreço:', linha[5])


    def atualizar(self, livros):
        sql = 'update livros set nome=%s, autor=%s, editora=%s, ano=%s, preco=%s where codigo=%s'
        valores = (livros.getCodigo(),livros.getNome(),livros.getAutor(), livros.getEditora,livros.getAno, livros.getPreco())
        if not self.conectar():
            return False
        self.cursor.execute(sql, valores)
        self.con.commit()
        if self.cursor.rowcount > 0:
            return True
        return False


    def excluir(self, livros):
        sql = 'delete from livros where codigo=%s'
        if not self.conectar():
            return False
        self.cursor.execute(sql)
        self.con.commit()
        if self.cursor.rowcount > 0:
            return True
        return False


'''pd=LivrosDAO()
livro=Livros.consultar(103)
print('Produto: ', Livros.getDescricao())'''